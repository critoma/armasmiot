package com.example.toupper2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.example.toupper2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Example of a call to a native method
        //binding.sampleText.text = stringFromJNI()

    }

    /**
     * A native method that is implemented by the 'toupper2' native library,
     * which is packaged with this application.
     */
    //external fun stringFromJNI(): String

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    //external fun toupperJNI(input: String): String
    //companion object {
    //    // Used to load the 'native-lib' library on application startup.
    //    init {
    //        System.loadLibrary("native-lib")
    //    }
    //}

    external fun toupperJNI(input: String): String
    companion object {
        // Used to load the 'toupper2' library on application startup.
        init {
            System.loadLibrary("toupper2")
        }
    }


    /** Called when the user taps the Send button */
    fun convertMessage(v: View) {
        // Do something in response to button
        val editText = findViewById<EditText>(R.id.enterText)
        val message = toupperJNI(editText.text.toString())
        val textView = findViewById<TextView>(R.id.convertedText).apply {
            text = message
        }
    }
}