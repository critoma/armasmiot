//#include <jni.h>
//#include <string>

//extern "C" JNIEXPORT jstring JNICALL
//Java_com_example_toupper2_MainActivity_stringFromJNI(
//        JNIEnv* env,
//        jobject /* this */) {
    //std::string hello = "Hello from C++";
    //return env->NewStringUTF(hello.c_str());
//}
#include <jni.h>
#include <string>

/*
// ARM 32 bits
@
@ Assembler program to convert a string to
@ all upper case.
@
@ R1 - address of output string
@ R0 - address of input string
@ R4 - original output string for length calc.
@ R5 - current character being processed
@

.global mytoupper	     @ Allow other files to call this routine

mytoupper:	PUSH	{R4-R5}	@ Save the registers we use.
	MOV	R4, R1
@ The loop is until byte pointed to by R1 is non-zero
loop:	LDRB	R5, [R0], #1	@ load character and increment pointer
@ If R5 > 'z' then goto cont
	CMP	R5, #'z'	    @ is letter > 'z'?
	BGT	cont
@ Else if R5 < 'a' then goto end if
	CMP	R5, #'a'
	BLT	cont	@ goto to end if
@ if we got here then the letter is lower case, so convert it.
	SUB	R5, #('a'-'A')
cont:	@ end if
	STRB	R5, [R1], #1	@ store character to output str
	CMP	R5, #0		@ stop on hitting a null character
	BNE	loop		@ loop if character isn't null
	SUB	R0, R1, R4  @ get the length by subtracting the pointers
	POP	{R4-R5}		@ Restore the register we use.
	BX	LR		@ Return to caller
 */

/*
// ARM 64 bits
// Assembler program to convert a string to
// all upper case.
//
// X1 - address of output string
// X0 - address of input string
// X4 - original output string for length calc.
// W5 - current character being processed
//

.global mytoupper	     // Allow other files to call this routine

mytoupper:
	MOV	X4, X1
// The loop is until byte pointed to by X1 is non-zero
loop:	LDRB	W5, [X0], #1	// load character and increment pointer
// If W5 > 'z' then goto cont
	CMP	W5, #'z'	    // is letter > 'z'?
	B.GT	cont
// Else if W5 < 'a' then goto end if
	CMP	W5, #'a'
	B.LT	cont	// goto to end if
// if we got here then the letter is lower case, so convert it.
	SUB	W5, W5, #('a'-'A')
cont:	// end if
	STRB	W5, [X1], #1	// store character to output str
	CMP	W5, #0		// stop on hitting a null character
	B.NE	loop		// loop if character isn't null
	SUB	X0, X1, X4  // get the length by subtracting the pointers
	RET		// Return to caller
*/

/*

int mytoupper( const char * input, char * output)
{
    int i = 0;

    while( input[i] != NULL ) {
        if (input[i] >= 'a' && input[i] <= 'z') {
            output[i] = input[i] - ('a' - 'A');
        } else
        {
            output[i] = input[i];
        }
        i++;
    }
    output[i] = NULL;
    return i;
}
*/
extern "C" int mytoupper( const char * input, char * output);

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_toupper2_MainActivity_toupperJNI(
        JNIEnv* env,
        jobject /* this */,
        jstring input) {
    char upperStr[255];

    mytoupper(env->GetStringUTFChars(input, NULL), upperStr);
    return env->NewStringUTF(upperStr);
}
