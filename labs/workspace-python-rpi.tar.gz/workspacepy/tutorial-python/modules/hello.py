# Import module support
import support

# Now you can call defined function that module as follows
support.print_func("Zara")
