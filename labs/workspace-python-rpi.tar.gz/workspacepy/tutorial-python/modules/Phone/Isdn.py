def Isdn():
   print ("I'm Isdn Phone") 
