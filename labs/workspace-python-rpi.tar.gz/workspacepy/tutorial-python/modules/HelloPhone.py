import sys
#sys.path.append( "/com/oracle/Phone" )
import Phone

print(sys.path)

Phone.Pots()
Phone.Isdn()
Phone.G3()
