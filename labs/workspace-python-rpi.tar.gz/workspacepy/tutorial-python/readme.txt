# http://www.tutorialspoint.com/python/
# http://www.tutorialspoint.com/python3/


cd /home/pi/workspacepy/tutorial-python
which python
python --version

which python3
python3 --version


python3 p003_strings.py
python3 p004_lists.py
python3 p005_tuples.py
python3 p006_dictionary.py
python3 p007_ifstatement.py
python3 p008_loopstatement.py
python3 p009_datetime.py




http://www.tutorialspoint.com/python3

https://www.python.org/downloads/windows/

D:
cd D:\Cristian\Oracle\P006_IoT_GW\docsKitsTutorials\tutorial-python
c:\Software\Python\Python35\python.exe p030_oop_class.py



# Modules:

D:\Cristian\Oracle\P006_IoT_GW\docsKitsTutorials\tutorial-python\modules>set PYTHONPATH=.;C:\Software\Python\Python35\Lib

D:\Cristian\Oracle\P006_IoT_GW\docsKitsTutorials\tutorial-python\modules>echo %PYTHONPATH%
.;.\Phone;C:\Software\Python\Python35\Lib



D:\Cristian\Oracle\P006_IoT_GW\docsKitsTutorials\tutorial-python\modules>c:\Sofware\Python\Python35\python.exe HelloPhone.py
I'm Pots Phone
I'm Isdn Phone
I'm 3G Phone


