console.log("Hello ...");
console.log('Node.js 8.9.0 / 9.0 supports EC6 - ECMAScript6/JavaScript')