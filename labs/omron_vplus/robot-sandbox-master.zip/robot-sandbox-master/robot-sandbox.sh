#!/bin/sh

cd sim-files
python main.py

